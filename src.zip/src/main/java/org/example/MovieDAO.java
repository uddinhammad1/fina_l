package org.example;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class MovieDAO {
    public MovieDAO() {
        DatabaseHelper.initializeDatabase();
    }

    public void addMovie(Movie movie) {
        String sql = "INSERT OR IGNORE INTO movies (id, title, genre, year, rating, revenue) VALUES (?, ?, ?, ?, ?, ?)";

        try (Connection conn = DatabaseHelper.connect(); PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, movie.getId());
            pstmt.setString(2, movie.getTitle());
            pstmt.setString(3, movie.getGenre());
            pstmt.setInt(4, movie.getYear());
            pstmt.setDouble(5, movie.getRating());
            pstmt.setString(6, movie.getRevenue());
            pstmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public List<Movie> getAllMovies() {
        List<Movie> movies = new ArrayList<>();
        String sql = "SELECT * FROM movies";

        try (Connection conn = DatabaseHelper.connect(); Statement stmt = conn.createStatement(); ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                Movie movie = new Movie(
                        rs.getString("id"),
                        rs.getString("title"),
                        rs.getString("genre"),
                        rs.getInt("year"),
                        rs.getDouble("rating"),
                        rs.getString("revenue")
                );
                movies.add(movie);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return movies;
    }

    public void batchUploadMoviesFromFile(String filePath) {
        String insertSQL = "INSERT OR IGNORE INTO movies (id, title, genre, year, rating, revenue) VALUES (?, ?, ?, ?, ?, ?)";

        try (BufferedReader reader = new BufferedReader(new FileReader(filePath));
             Connection conn = DatabaseHelper.connect();
             PreparedStatement pstmt = conn.prepareStatement(insertSQL)) {

            conn.setAutoCommit(false); // Start a transaction for batch processing

            String line;
            while ((line = reader.readLine()) != null) {
                String[] movieData = line.split(","); // Assuming CSV format: id,title,genre,year,rating,revenue
                if (movieData.length < 6) {
                    System.out.println("Skipping invalid line: " + line);
                    continue; // Skip lines that don't match expected format
                }

                String id = movieData[0].trim();
                String title = movieData[1].trim();
                String genre = movieData[2].trim();
                int year = Integer.parseInt(movieData[3].trim());
                double rating = Double.parseDouble(movieData[4].trim());
                String revenue = movieData[5].trim();

                // Check for duplicate based on id or title
                if (isDuplicateEntry(id, title)) {
                    System.out.println("Duplicate entry found for ID: " + id + ", Title: " + title + ". Skipping entry.");
                    continue;
                }

                // Insert movie data
                pstmt.setString(1, id);
                pstmt.setString(2, title);
                pstmt.setString(3, genre);
                pstmt.setInt(4, year);
                pstmt.setDouble(5, rating);
                pstmt.setString(6, revenue);
                pstmt.addBatch(); // Add to batch
            }

            pstmt.executeBatch(); // Execute the batch
            conn.commit(); // Commit the transaction

        } catch (IOException | SQLException e) {
            e.printStackTrace();
        }
    }

    private boolean isDuplicateEntry(String id, String title) {
        String checkSQL = "SELECT 1 FROM movies WHERE id = ? OR title = ?";

        try (Connection conn = DatabaseHelper.connect();
             PreparedStatement pstmt = conn.prepareStatement(checkSQL)) {

            pstmt.setString(1, id);
            pstmt.setString(2, title);
            ResultSet rs = pstmt.executeQuery();
            return rs.next(); // Returns true if a record with the same id or title exists

        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public void removeMovieById(String id) {
        String sql = "DELETE FROM movies WHERE id = ?";

        try (Connection conn = DatabaseHelper.connect(); PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, id);
            pstmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public void removeMovieByTitle(String title) {
        String sql = "DELETE FROM movies WHERE title = ?";

        try (Connection conn = DatabaseHelper.connect(); PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, title);
            pstmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public double calculateAverageRating() {
        String sql = "SELECT AVG(rating) AS avg_rating FROM movies";
        try (Connection conn = DatabaseHelper.connect(); Statement stmt = conn.createStatement(); ResultSet rs = stmt.executeQuery(sql)) {
            if (rs.next()) {
                return rs.getDouble("avg_rating");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return 0.0;
    }

    // Update movie details by ID
    public boolean updateMovie(String id, String title, String genre, int year, double rating, String revenue) {
        // First check if the movie exists by ID
        String checkSQL = "SELECT 1 FROM movies WHERE id = ?";
        try (Connection conn = DatabaseHelper.connect();
             PreparedStatement pstmt = conn.prepareStatement(checkSQL)) {
            pstmt.setString(1, id);
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                // Check for duplicates before updating
                if (isDuplicateEntry(id, title)) {
                    System.out.println("Duplicate entry found for ID: " + id + ", Title: " + title + ". Update failed.");
                    return false; // Prevent duplicate updates
                }

                // Update movie details
                String updateSQL = "UPDATE movies SET title = ?, genre = ?, year = ?, rating = ?, revenue = ? WHERE id = ?";
                try (PreparedStatement updateStmt = conn.prepareStatement(updateSQL)) {
                    updateStmt.setString(1, title);
                    updateStmt.setString(2, genre);
                    updateStmt.setInt(3, year);
                    updateStmt.setDouble(4, rating);
                    updateStmt.setString(5, revenue);
                    updateStmt.setString(6, id);
                    updateStmt.executeUpdate();
                    System.out.println("Movie with ID " + id + " updated successfully.");
                    return true;
                }
            } else {
                System.out.println("No movie found with ID: " + id);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }
}