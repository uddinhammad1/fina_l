package org.example;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.util.List;

public class Main extends JFrame {
    private MovieDAO movieDAO;
    private JTable movieTable;
    private DefaultTableModel tableModel;

    public Main() {
        movieDAO = new MovieDAO();  // Initialize the MovieDAO

        // Set up the JFrame
        setTitle("Movie Manager");
        setSize(800, 500);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());

        // Create the JTable for displaying movies
        String[] columnNames = {"ID", "Title", "Genre", "Year", "Rating", "Revenue"};
        tableModel = new DefaultTableModel(columnNames, 0);
        movieTable = new JTable(tableModel);
        movieTable.setFillsViewportHeight(true);
        JScrollPane scrollPane = new JScrollPane(movieTable);

        // Add components to the JFrame
        add(scrollPane, BorderLayout.CENTER);

        // Create the bottom panel with buttons
        JPanel bottomPanel = new JPanel();
        bottomPanel.setLayout(new FlowLayout());

        // Buttons
        JButton addButton = new JButton("Add Movie");
        JButton updateButton = new JButton("Update Movie");
        JButton deleteButton = new JButton("Delete Movie");
        JButton batchUploadButton = new JButton("Batch Upload");

        bottomPanel.add(addButton);
        bottomPanel.add(updateButton);
        bottomPanel.add(deleteButton);
        bottomPanel.add(batchUploadButton);

        add(bottomPanel, BorderLayout.SOUTH);

        // Add action listeners for buttons
        addButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                addMovie();
            }
        });

        updateButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                updateMoviesFromTable();
            }
        });

        deleteButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                deleteMovie();
            }
        });

        batchUploadButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                batchUploadMovies();
            }
        });

        // Load movies into the JTable
        loadMoviesIntoTable();
    }

    private void loadMoviesIntoTable() {
        List<Movie> movies = movieDAO.getAllMovies();
        tableModel.setRowCount(0);  // Clear existing data from the table

        // Add movies to the table
        for (Movie movie : movies) {
            tableModel.addRow(new Object[]{
                    movie.getId(),
                    movie.getTitle(),
                    movie.getGenre(),
                    movie.getYear(),
                    movie.getRating(),
                    movie.getRevenue()
            });
        }
    }

    private void addMovie() {
        String id = JOptionPane.showInputDialog(this, "Enter Movie ID:");
        String title = JOptionPane.showInputDialog(this, "Enter Movie Title:");
        String genre = JOptionPane.showInputDialog(this, "Enter Movie Genre:");
        int year = Integer.parseInt(JOptionPane.showInputDialog(this, "Enter Movie Year:"));
        double rating = Double.parseDouble(JOptionPane.showInputDialog(this, "Enter Movie Rating:"));
        String revenue = JOptionPane.showInputDialog(this, "Enter Movie Revenue:");

        Movie movie = new Movie(id, title, genre, year, rating, revenue);
        movieDAO.addMovie(movie);
        loadMoviesIntoTable();  // Refresh the table after adding
        JOptionPane.showMessageDialog(this, "Movie added successfully!");
    }

    private void updateMoviesFromTable() {
        int rowCount = movieTable.getRowCount();
        for (int i = 0; i < rowCount; i++) {
            String id = movieTable.getValueAt(i, 0).toString();
            String title = movieTable.getValueAt(i, 1).toString();
            String genre = movieTable.getValueAt(i, 2).toString();
            int year = Integer.parseInt(movieTable.getValueAt(i, 3).toString());
            double rating = Double.parseDouble(movieTable.getValueAt(i, 4).toString());
            String revenue = movieTable.getValueAt(i, 5).toString();

            // Update movie in the database
            movieDAO.updateMovie(id, title, genre, year, rating, revenue);
        }

        JOptionPane.showMessageDialog(this, "Movies updated successfully!");
    }

    private void deleteMovie() {
        int selectedRow = movieTable.getSelectedRow();
        if (selectedRow != -1) {
            String id = movieTable.getValueAt(selectedRow, 0).toString();
            int confirm = JOptionPane.showConfirmDialog(this, "Are you sure you want to delete this movie?");
            if (confirm == JOptionPane.YES_OPTION) {
                movieDAO.removeMovieById(id);
                loadMoviesIntoTable();  // Refresh the table after deletion
                JOptionPane.showMessageDialog(this, "Movie deleted successfully!");
            }
        } else {
            JOptionPane.showMessageDialog(this, "Please select a movie to delete.");
        }
    }

    private void batchUploadMovies() {
        JFileChooser fileChooser = new JFileChooser();
        int returnValue = fileChooser.showOpenDialog(this);

        if (returnValue == JFileChooser.APPROVE_OPTION) {
            File file = fileChooser.getSelectedFile();
            movieDAO.batchUploadMoviesFromFile(file.getAbsolutePath());
            loadMoviesIntoTable();  // Refresh the table after batch upload
            JOptionPane.showMessageDialog(this, "Movies uploaded successfully!");
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                new Main().setVisible(true);
            }
        });
    }
}