package org.example;

import java.io.BufferedReader;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.List;

/**
 * Utility class for reading movie data from a file.
 */
public class MovieFileReader {

    public static List<Movie> readMoviesFromFile(String filePath) {
        List<Movie> movies = new ArrayList<>();

        try (BufferedReader br = new BufferedReader(new FileReader(filePath))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] parts = line.split(",");
                if (parts.length == 6) {
                    Movie movie = new Movie(
                            parts[0], parts[1], parts[2], Integer.parseInt(parts[3]),
                            Double.parseDouble(parts[4]), parts[5]
                    );
                    movies.add(movie);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        return movies;
    }
}
