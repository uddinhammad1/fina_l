package org.example;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

/**
 * DatabaseHelper manages the SQLite database connection and initialization.
 */
public class DatabaseHelper {
    private static final String URL = "jdbc:sqlite:movies.db";

    /**
     * Establishes a connection to the SQLite database.
     *
     * @return Connection to the database.
     * @throws SQLException if a database access error occurs.
     */
    public static Connection connect() throws SQLException {
        return DriverManager.getConnection(URL);
    }

    /**
     * Initializes the database by creating the 'movies' table if it does not exist.
     */
    public static void initializeDatabase() {
        String createTableSQL = "CREATE TABLE IF NOT EXISTS movies ("
                + "id TEXT PRIMARY KEY, "
                + "title TEXT UNIQUE NOT NULL, "
                + "genre TEXT, "
                + "year INTEGER, "
                + "rating REAL, "
                + "revenue TEXT"
                + ");";

        try (Connection conn = connect(); Statement stmt = conn.createStatement()) {
            stmt.execute(createTableSQL);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
